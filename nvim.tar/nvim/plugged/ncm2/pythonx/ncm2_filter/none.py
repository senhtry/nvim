
def Filter(**kargs):
    def filt(data, sr, sctx, sccol, matches):
        return matches
    return filt
