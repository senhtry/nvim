
def Sorter(**kargs):
    def sort(matches: list):
        return matches
    return sort

