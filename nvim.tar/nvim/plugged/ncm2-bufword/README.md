# ncm2-bufword

This ncm2 plugin provide words from current buffer for completion.

![ncm2-bufword](https://user-images.githubusercontent.com/4538941/51012266-50b82080-1597-11e9-96df-7e5dcbff4b81.png)

